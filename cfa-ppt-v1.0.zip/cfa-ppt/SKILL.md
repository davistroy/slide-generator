# CFA PPT Skill v1.0

Generate branded Chick-fil-A PowerPoint presentations programmatically.

## Overview

This skill creates professional CFA-branded presentations with proper colors, fonts, logos, and layouts matching the official CFA PowerPoint template.

## Brand Elements

### Colors
| Name | Hex | Usage |
|------|-----|-------|
| CFA Red | `#DD0033` | Title slide background, primary brand color |
| Dark Blue | `#004F71` | Section break backgrounds |
| Light Gray | `#EEEDEB` | Text+image panel background |
| Text Gray | `#5B6770` | Body text, bullets, slide titles |
| White | `#FFFFFF` | Text on dark backgrounds |

### Fonts
- **Primary Font**: Apercu (headings and body)
- **Bullet Symbol**: § (Wingdings)

### Slide Dimensions
- Widescreen 16:9 (13.33" × 7.50")

## Installation

```python
import sys
sys.path.insert(0, '/path/to/cfa-ppt')
from cfa import CFAPresentation
```

## Slide Types

### 1. Title Slide
Red background with white CFA compass logo.

```python
prs.add_title_slide(
    title="Presentation Title",
    subtitle="Optional Subtitle",
    date="November 2025"
)
```

### 2. Section Break
Dark blue (#004F71) background for section dividers.

```python
prs.add_section_break("Section Name")
```

### 3. Content Slide
White background with title, subtitle, and bulleted content.

```python
prs.add_content_slide(
    title="Slide Title",
    subtitle="Optional subtitle",
    bullets=[
        ("Main bullet point", 0),      # Level 0 = main bullet
        ("Sub-bullet point", 1),       # Level 1 = indented
        ("Sub-sub-bullet", 2),         # Level 2 = double indent
    ]
)
```

### 4. Image Slide
Full-width image with title and optional subtitle.

```python
prs.add_image_slide(
    title="Image Title",
    image_path="/path/to/image.jpg",
    subtitle="Optional caption"
)
```

### 5. Text + Image Slide
Gray left panel with bullets, image on right.

```python
prs.add_text_and_image_slide(
    title="Panel Title",
    bullets=[
        ("Key point one", 0),
        ("Supporting detail", 1),
    ],
    image_path="/path/to/image.jpg"
)
```

## Complete Example

```python
from cfa import CFAPresentation

prs = CFAPresentation()

# Cover slide
prs.add_title_slide(
    "Q4 Business Review",
    "Operations Update",
    "November 2025"
)

# Section divider
prs.add_section_break("Executive Summary")

# Content with bullets
prs.add_content_slide("Key Highlights", "Year-to-Date", [
    ("Revenue exceeded targets by 8%", 0),
    ("Drive-thru efficiency up 12%", 1),
    ("Mobile orders up 25% YoY", 1),
    ("Guest satisfaction at all-time high", 0),
])

# Image slide
prs.add_image_slide(
    "Restaurant Locations",
    "/path/to/map.png",
    "New openings by region"
)

# Text and image combination
prs.add_text_and_image_slide(
    "Team Excellence",
    [
        ("Recruitment highlights", 0),
        ("Hired 15,000 new team members", 1),
        ("Training & Development", 0),
        ("New leadership program launched", 1),
    ],
    "/path/to/team_photo.jpg"
)

# Closing section
prs.add_section_break("Questions?")

# Save
prs.save("q4_review.pptx")
```

## Assets Included

| File | Description |
|------|-------------|
| `logo_white.png` | White CFA compass logo for title slide |
| `chicken_red.png` | Red chicken icon for slide footers (white backgrounds) |
| `chicken_white.png` | White chicken icon for slide footers (dark backgrounds) |

## Bullet Formatting

Bullets use the CFA standard Wingdings § character with proper indentation:

| Level | Left Margin | Font Size | Usage |
|-------|-------------|-----------|-------|
| 0 | 0.312" | 15pt | Main points |
| 1 | 0.646" | 13pt | Supporting details |
| 2 | 0.979" | 11pt | Additional detail |

## Dependencies

- python-pptx
- Pillow (PIL)
- lxml

## File Structure

```
cfa-ppt/
├── SKILL.md          # This documentation
├── cfa.py            # Main Python module
└── assets/
    ├── logo_white.png
    ├── chicken_red.png
    └── chicken_white.png
```
