# Stratfield PowerPoint Presentation Skill

## Overview

This skill generates professional PowerPoint presentations using the Stratfield Consulting corporate template. It provides a Python API that handles all brand styling, positioning, and formatting automatically.

## Quick Start

```python
from stratfield import StratfieldPresentation

prs = StratfieldPresentation()

# Add slides
prs.add_title_slide("Project Proposal", "Driving Digital Excellence", "January 2025")
prs.add_section_break("Executive Summary")
prs.add_content_slide("Key Objectives", [
    ("Modernize technology infrastructure", 0),
    ("Reduce costs by 30%", 1),
    ("Improve customer satisfaction", 1),
    ("Enable data-driven decisions", 0),
])
prs.add_image_slide("Architecture Overview", "/path/to/diagram.png")

prs.save("/mnt/user-data/outputs/presentation.pptx")
```

## Installation

Requires `python-pptx` and `lxml`:

```bash
pip install python-pptx lxml
```

## API Reference

### StratfieldPresentation

```python
prs = StratfieldPresentation(assets_dir=None)
```

Creates a new presentation. The `assets_dir` parameter is optional and defaults to the `assets/` folder adjacent to the module.

---

### add_title_slide(title, subtitle, date)

Creates the opening slide with gradient background and logo.

```python
prs.add_title_slide(
    title="Digital Transformation Strategy",
    subtitle="Accelerating Growth Through Technology",
    date="Q1 2025 Executive Briefing"
)
```

---

### add_section_break(title)

Creates a section divider slide with dark teal background and centered title.

```python
prs.add_section_break("Implementation Approach")
```

---

### add_content_slide(title, bullets)

Creates a content slide with title and bullet points. Bullets use native PowerPoint formatting for easy manual editing.

```python
prs.add_content_slide("Strategic Priorities", [
    ("First main point", 0),           # Level 0 = main bullet
    ("Supporting detail", 1),           # Level 1 = sub-bullet
    ("Another detail", 1),
    ("Second main point", 0),
    ("Deep detail", 2),                 # Level 2 = sub-sub-bullet
])
```

**Bullet Levels:**
| Level | Indent | Font Size | Use For |
|-------|--------|-----------|---------|
| 0 | 0.19" | 14pt | Main points |
| 1 | 0.37" | 12pt | Supporting details |
| 2 | 0.63" | 11pt | Additional details |

---

### add_image_slide(title, image_path)

Creates a slide with title and full-width image.

```python
prs.add_image_slide(
    "System Architecture",
    "/path/to/architecture_diagram.png"
)
```

**Recommended image size:** 920 × 430 pixels (or same aspect ratio)

---

### add_text_and_image_slide(title, bullets, image_path)

Creates a two-column layout with dark left panel (text) and image on right.

```python
prs.add_text_and_image_slide(
    "Implementation Phases",
    [
        ("Phase 1: Discovery", 0),
        ("Stakeholder interviews", 1),
        ("Requirements analysis", 1),
        ("Phase 2: Build", 0),
        ("Core development", 1),
    ],
    "/path/to/roadmap.png"
)
```

**Recommended image size:** 570 × 450 pixels (or same aspect ratio)

---

### save(filename)

Saves the presentation to a file.

```python
prs.save("/mnt/user-data/outputs/my_presentation.pptx")
```

---

## Slide Layouts

### Title Slide
Full gradient background with logo, title, subtitle, and date.

```
┌─────────────────────────────────────────┐
│ ┌──────────┐                            │
│ │  LOGO    │                            │
│ └──────────┘                            │
│                                         │
│  Title Text (32pt, Avenir Black)        │
│  Subtitle (20pt, Avenir)                │
│  Date (16pt, Avenir Light)              │
└─────────────────────────────────────────┘
```

### Section Break
Dark teal background with centered title and tree logo mark.

```
┌─────────────────────────────────────────┐
│                                         │
│         Section Title (centered)        │
│                                         │
│              ┌─────┐                    │
│              │ 🌲  │                    │
│              └─────┘                    │
│                                    [##] │
└─────────────────────────────────────────┘
```

### Content - Text Only
Light background with title, bullets, and branded footer.

```
┌─────────────────────────────────────────┐
│ Slide Title                             │
│─────────────────────────────────────────│
│ ■ Bullet point level 0                  │
│   ■ Sub-bullet level 1                  │
│     ■ Sub-sub-bullet level 2            │
│ ■ Another main bullet                   │
│                                         │
│▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ [##]│
└─────────────────────────────────────────┘
```

### Content - Full Image
Title with large image area.

```
┌─────────────────────────────────────────┐
│ Slide Title                             │
│┌───────────────────────────────────────┐│
││                                       ││
││              IMAGE                    ││
││           (9.20" × 4.30")             ││
││                                       ││
│└───────────────────────────────────────┘│
│▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ [##]│
└─────────────────────────────────────────┘
```

### Content - Text and Image
Two-column with dark left panel.

```
┌───────────────┬─────────────────────────┐
│ Title (white) │                         │
│───────────────│                         │
│ ■ Bullet      │         IMAGE           │
│   ■ Sub       │      (5.70" × 4.50")    │
│ ■ Bullet      │                         │
│               │                         │
│  DARK PANEL   │                         │
│▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ [##]│
└───────────────┴─────────────────────────┘
```

---

## Brand Specifications

### Colors

| Name | Hex | Usage |
|------|-----|-------|
| Primary Green | `#00764F` | Bullets, links, accents |
| Dark Teal | `#296057` | Content titles, panels |
| Section BG | `#30555E` | Section break background |
| Light Gray | `#F2F2F2` | Content slide background |
| Title Cream | `#DDFAD3` | Title text on dark backgrounds |
| Body Text | `#637878` | Body text on light backgrounds |

### Typography

| Element | Font | Size | Color |
|---------|------|------|-------|
| Cover Title | Avenir Black | 32pt | #DDFAD3 |
| Section Title | Avenir Black | 32pt | #DDF9D3 |
| Content Title | Avenir Black | 20pt | #296057 |
| Panel Title | Avenir Black | 14pt | #FFFFFF |
| Subtitle | Avenir | 20pt | #F2F2F2 |
| Date | Avenir Light | 16pt | #F2F2F2 |
| Body L0 | Avenir | 14pt | #637878 |
| Body L1 | Avenir | 12pt | #637878 |
| Body L2 | Avenir | 11pt | #637878 |

**Fallback fonts:** Arial family (if Avenir unavailable)

### Bullets

- **Character:** § (Wingdings small square)
- **Color:** Primary Green (#00764F)
- **Native PowerPoint formatting** for easy manual editing

---

## Assets

The `assets/` folder contains required images:

| File | Description | Dimensions |
|------|-------------|------------|
| `title_background.png` | Gradient background for title slide | 3840 × 2160 |
| `logo_title.png` | Full logo for title slide | 1123 × 583 |
| `logo_mark.png` | Tree icon for section breaks | 369 × 583 |
| `footer_bar.png` | Gradient bar for content footers | 3840 × 156 |
| `logo_footer.png` | Small logo for content footers | 1089 × 435 |

---

## Complete Example

```python
from stratfield import StratfieldPresentation

prs = StratfieldPresentation()

# Title
prs.add_title_slide(
    "Digital Transformation Strategy",
    "Accelerating Growth Through Technology Innovation",
    "Q1 2025 Executive Briefing"
)

# Section: Executive Summary
prs.add_section_break("Executive Summary")

prs.add_content_slide("Strategic Objectives", [
    ("Modernize core technology infrastructure", 0),
    ("Reduce legacy dependencies by 60%", 1),
    ("Enable real-time analytics", 1),
    ("Enhance customer experience", 0),
    ("Launch mobile platform by Q3", 1),
    ("Build organizational capabilities", 0),
])

# Section: Assessment
prs.add_section_break("Current State Assessment")

prs.add_content_slide("Key Findings", [
    ("Technology Landscape", 0),
    ("47 applications across 6 business units", 1),
    ("Average system age: 12 years", 1),
    ("Operational Challenges", 0),
    ("35% manual processing workload", 1),
    ("14-day customer onboarding vs. 3-day benchmark", 1),
])

# Section: Implementation
prs.add_section_break("Implementation Approach")

prs.add_image_slide("Solution Architecture", "/path/to/architecture.png")

prs.add_text_and_image_slide(
    "Phased Delivery",
    [
        ("Phase 1: Discovery", 0),
        ("Stakeholder alignment", 1),
        ("Requirements gathering", 1),
        ("Phase 2: Build", 0),
        ("Core platform setup", 1),
        ("Integration development", 1),
        ("Phase 3: Deploy", 0),
        ("Pilot launch", 1),
        ("Full rollout", 1),
    ],
    "/path/to/roadmap.png"
)

# Section: Investment
prs.add_section_break("Investment & Returns")

prs.add_content_slide("Business Case", [
    ("Total Investment: $4.2M over 24 months", 0),
    ("Phase 1: $1.8M - Infrastructure", 1),
    ("Phase 2: $1.6M - Applications", 1),
    ("Phase 3: $0.8M - Optimization", 1),
    ("Projected Returns", 0),
    ("Annual savings: $2.4M", 1),
    ("Revenue enablement: $3.1M", 1),
    ("ROI: 156% over 3 years", 0),
])

# Closing
prs.add_section_break("Questions & Discussion")

prs.save("/mnt/user-data/outputs/transformation_strategy.pptx")
```

---

## File Structure

```
stratfield-skill/
├── SKILL.md           # This documentation
├── stratfield.py      # Python module
└── assets/
    ├── title_background.png
    ├── logo_title.png
    ├── logo_mark.png
    ├── footer_bar.png
    └── logo_footer.png
```
